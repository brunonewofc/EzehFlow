import './assets/index.ts-BMK0yL7E.js';

// EzehFlow — Auto-recovery handler for "actividad inusual" rate limit errors
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CLEAR_CACHE_FOR_RECOVERY') {
    (async () => {
      try {
        // Clear non-essential cookies for labs.google and flow.google.com
        // __Host-* and OSID are Google session cookies: deleting them logs the user out.
        const safePrefixes = ["__Secure","__Host","SID","SSID","HSID","APISID","SAPISID","LSID","NID","1P_JAR","OSID"];
        const cookies = [
          ...(await chrome.cookies.getAll({domain: "labs.google"})),
          ...(await chrome.cookies.getAll({domain: "flow.google.com"})),
        ];
        await Promise.all(
          cookies.filter(c => !safePrefixes.some(p => c.name.startsWith(p)))
            .map(c => chrome.cookies.remove({
              url: `https://${c.domain.replace(/^\./, '')}${c.path}`,
              name: c.name
            }))
        );

        // Clear local storage via Chrome debugger on the sender tab
        if (sender.tab && sender.tab.id) {
          const tabId = sender.tab.id;
          try {
            await chrome.debugger.attach({tabId}, "1.3");
            await chrome.debugger.sendCommand({tabId}, "Storage.clearDataForOrigin", {
              origin: sender.tab.url ? new URL(sender.tab.url).origin : "https://labs.google",
              storageTypes: "local_storage"
            });
            await chrome.debugger.detach({tabId});
          } catch (e) {
            console.log('[EzehFlow] debugger attach error (non-fatal):', e);
          }
          // Reload the tab — auto-recovery content script will continue queue on re-init
          await chrome.tabs.reload(tabId);
        }
        sendResponse({success: true});
      } catch (e) {
        console.log('[EzehFlow] recovery error:', e);
        sendResponse({success: false});
      }
    })();
    return true; // keep channel open for async sendResponse
  }
});
