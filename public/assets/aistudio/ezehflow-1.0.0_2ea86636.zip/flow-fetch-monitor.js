// Injected into the MAIN world of labs.google so we can observe page fetches
// (content scripts can't see them directly). We watch for HTTP errors from the
// Flow batch generation endpoint — that's the cleanest possible signal that
// our prompt was rejected by content policy or similar.
(function () {
  if (window.__fa_fetch_patched) return;
  window.__fa_fetch_patched = true;

  const originalFetch = window.fetch;
  window.fetch = function (...args) {
    const url =
      typeof args[0] === "string"
        ? args[0]
        : args[0] && typeof args[0].url === "string"
          ? args[0].url
          : "";

    // Two endpoint families matter, tagged with `kind` so the content script
    // never mixes them up: generation errors fail the prompt; upsample errors
    // only fail the 2K/4K download click (fallback to direct download).
    const kindFor = (u) =>
      /flowMedia:(batchGenerateImages|batchGenerateVideos)/i.test(u)
        ? "generate"
        : /\/flow\/upsampleImage/i.test(u)
          ? "upsample"
          : null;

    return originalFetch.apply(this, args).then(
      (response) => {
        const kind = typeof url === "string" ? kindFor(url) : null;
        if (kind && !response.ok) {
          window.postMessage(
            {
              __fa_flow_error: true,
              kind,
              status: response.status,
              url,
              at: Date.now(),
            },
            "*",
          );
        }
        return response;
      },
      (err) => {
        // Network-level failures (offline, CORS) also matter.
        const kind = typeof url === "string" ? kindFor(url) : null;
        if (kind) {
          window.postMessage(
            {
              __fa_flow_error: true,
              kind,
              status: 0,
              url,
              error: String(err),
              at: Date.now(),
            },
            "*",
          );
        }
        throw err;
      },
    );
  };

  window.addEventListener("error", function (e) {
    window.postMessage({ __fa_page_error: true, message: String(e.message || ""), src: String(e.filename || ""), line: e.lineno || 0 }, "*");
  });
  window.addEventListener("unhandledrejection", function (e) {
    window.postMessage({ __fa_page_error: true, message: "unhandled: " + String((e.reason && e.reason.message) || e.reason) }, "*");
  });
})();

(function () {
  if (window.__fa_picker_patched) return;
  window.__fa_picker_patched = true;
  // --- file picker suppression (on demand, set via postMessage by the content script) ---
  window.__fa_block_file_picker = false;
  window.addEventListener("message", function (e) {
    if (e.source !== window) return;
    const d = e.data;
    if (d && typeof d.__fa_block_file_picker === "boolean") {
      window.__fa_block_file_picker = d.__fa_block_file_picker;
    }
  });
  const faOrigClick = HTMLInputElement.prototype.click;
  HTMLInputElement.prototype.click = function () {
    if (this && this.type === "file" && window.__fa_block_file_picker) {
      try {
        if (!this.isConnected) document.body.appendChild(this);
        this.setAttribute("data-fa-file-input", "1");
        this.style.display = "none";
      } catch (e) {}
      return; // do not open the native chooser
    }
    return faOrigClick.apply(this, arguments);
  };
  const faOrigShowPicker = HTMLInputElement.prototype.showPicker;
  if (typeof faOrigShowPicker === "function") {
    HTMLInputElement.prototype.showPicker = function () {
      if (this && this.type === "file" && window.__fa_block_file_picker) {
        try {
          if (!this.isConnected) document.body.appendChild(this);
          this.setAttribute("data-fa-file-input", "1");
          this.style.display = "none";
        } catch (e) {}
        return;
      }
      return faOrigShowPicker.apply(this, arguments);
    };
  }
  if (typeof window.showOpenFilePicker === "function") {
    const faOrigOpenPicker = window.showOpenFilePicker;
    window.showOpenFilePicker = function () {
      if (window.__fa_block_file_picker) {
        window.postMessage({ __fa_file_picker_blocked: true, at: Date.now() }, "*");
        return Promise.reject(new DOMException("File picker blocked by extension", "AbortError"));
      }
      return faOrigOpenPicker.apply(this, arguments);
    };
  }
})();
