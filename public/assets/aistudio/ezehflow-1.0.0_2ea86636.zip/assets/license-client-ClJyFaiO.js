// EzehFlow — la extensión es gratis e ilimitada.
//
// Este módulo conserva el mismo contrato de exports que consumen los bundles
// minificados (a, c, h, r), pero sin servidor de licencias, sin tier de pago y
// sin cupo diario: el estado que se guarda es siempre free/unlimited.
import { e as getLicense, k as saveLicense } from "./storage-DGjPwJKb.js";

const DEFAULT_EMAIL = "ezehflow@local";

function freeLicense(email, extra) {
  return Object.assign(
    {
      email: email || DEFAULT_EMAIL,
      tier: "free",
      unlimited: true,
      dailyLimit: null,
      internal: false,
      checkedAt: Date.now(),
    },
    extra || {}
  );
}

async function activate(email) {
  const license = freeLicense(email);
  await saveLicense(license);
  return license;
}

async function reset() {
  const current = await getLicense();
  const license = freeLicense(current && current.email, {
    dailyCount: current && current.dailyCount,
    dayKey: current && current.dayKey,
  });
  await saveLicense(license);
  return license;
}

async function current() {
  const current = await getLicense();
  return freeLicense(current && current.email, {
    dailyCount: current && current.dailyCount,
    dayKey: current && current.dayKey,
  });
}

function canGenerate() {
  return true;
}

export { activate as a, reset as c, canGenerate as h, current as r };
