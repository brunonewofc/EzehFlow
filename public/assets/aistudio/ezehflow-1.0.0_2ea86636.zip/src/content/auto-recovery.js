// EzehFlow - Auto-recovery for "actividad inusual" errors
// Detects the error tile in Google Flow, clears cache, and continues the queue.
//
// The old auto-continue flag was a bare boolean in storage.local: if the reload
// never happened (debugger failure, tab closed), the next visit to Flow resumed
// the queue on its own. Now the flag carries a timestamp and is consumed once:
//   - only a fresh flag (< 5 min) triggers CONTINUE_QUEUE;
//   - a watchdog removes it after 30 s if the page was never reloaded.
(function() {
  'use strict';

  var FLAG = 'autoContinueAfterClear';
  var MAX_AGE_MS = 5 * 60 * 1000;
  var WATCHDOG_MS = 30 * 1000;

  // ---- On init: auto-continue queue after cache clear + reload ----
  chrome.storage.local.get(FLAG, function(data) {
    var flag = data && data[FLAG];
    if (!flag) return;

    // Consume the flag exactly once, whatever the outcome below.
    try { chrome.storage.local.remove(FLAG); } catch (e) {}

    var at = flag && typeof flag === 'object' ? Number(flag.at) || 0 : 0;
    if (!at || Date.now() - at > MAX_AGE_MS) {
      // A stale flag (tab closed, reload failed on a previous visit) must not
      // resume the queue behind the user's back.
      return;
    }

    // Wait for page + content script to fully initialize before continuing
    setTimeout(function() {
      chrome.runtime.sendMessage({type: 'CONTINUE_QUEUE', recovery: true});
    }, 3000);
  });

  // ---- Watch for "actividad inusual" error tiles ----
  function watchForErrors() {
    if (!document.body) {
      setTimeout(watchForErrors, 500);
      return;
    }

    var observer = new MutationObserver(function(mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var mutation = mutations[i];
        // characterData = el texto cambio dentro de un nodo existente (Angular
        // actualiza textContent in-place, no agrega nodos: hay que mirar tambien
        // el target, no solo addedNodes).
        var candidates = [];
        if (mutation.type === 'characterData') {
          candidates.push(mutation.target);
        } else {
          for (var j = 0; j < mutation.addedNodes.length; j++) {
            candidates.push(mutation.addedNodes[j]);
          }
        }
        for (var k = 0; k < candidates.length; k++) {
          // textContent funciona igual en nodos de texto (nodeType 3) y en
          // elementos: no hay que filtrar por nodeType.
          var text = (candidates[k].textContent || '').toLowerCase();
          if (text.indexOf('actividad inusual') !== -1) {
            observer.disconnect();
            console.log('[EzehFlow] Detected "actividad inusual" error — clearing cache...');
            // Store a timestamped flag so the next content script init only
            // continues the queue if the reload actually happens soon.
            try {
              chrome.storage.local.set({autoContinueAfterClear: {at: Date.now()}}, function() {
                // Tell background to clear cache
                chrome.runtime.sendMessage({type: 'CLEAR_CACHE_FOR_RECOVERY'});
              });
            } catch (e) {
              chrome.runtime.sendMessage({type: 'CLEAR_CACHE_FOR_RECOVERY'});
            }
            // If the reload never comes (debugger/cookies failed, tab closed),
            // drop the flag so it cannot leak into a later visit.
            setTimeout(function() {
              try { chrome.storage.local.remove(FLAG); } catch (e) {}
            }, WATCHDOG_MS);
            return;
          }
        }
      }
    });

    observer.observe(document.body, {childList: true, subtree: true, characterData: true});
  }

  watchForErrors();
})();
