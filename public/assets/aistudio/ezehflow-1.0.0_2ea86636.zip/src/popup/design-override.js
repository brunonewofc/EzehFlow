// EzehFlow — UI override: pestanas + layout compacto sin scroll
(function () {
  'use strict';

  var css = [
    /* ---------- shell ---------- */
    '.panel-in{max-width:none!important;padding:6px 8px 8px!important;display:flex!important;flex-direction:column!important;gap:6px!important}',
    '.panel-in > *{margin-top:0!important;margin-bottom:0!important}',
    '.panel-in > header,.account-panel,.limit-modal{display:none!important}',
    'html,body{overflow-x:hidden!important}',
    '.aurora{opacity:.35!important}',

    /* tab visibility + block order */
    'body[data-ez-tab="1"] [data-ezp="2"],body[data-ez-tab="2"] [data-ezp="1"]{display:none!important}',
    '[data-ez-block="settings"]{order:1}',
    '[data-ez-block="prompts"]{order:2}',
    '[data-ez-block="run"]{order:3}',
    '[data-ez-block="folder"]{order:4}',
    '[data-ez-block="queue"]{order:5}',
    '[data-ez-block="continue"]{order:6}',
    '[data-ez-block="actions"]{order:7}',
    '[data-ez-block="lang"]{order:8}',

    /* tab 2: carpeta -> prompts -> cola -> limpiar prompts */
    'body[data-ez-tab="2"] [data-ez-block="folder"]{order:1}',
    'body[data-ez-tab="2"] [data-ez-block="prompts"]{order:2}',
    'body[data-ez-tab="2"] [data-ez-block="queue"]{order:3}',
    'body[data-ez-tab="2"] [data-ez-block="clear"]{order:4}',
    'body[data-ez-tab="2"] [data-ez-block="settings"]{order:5}',
    'body[data-ez-tab="2"] [data-ez-block="continue"]{order:5}',
    'body[data-ez-tab="2"] [data-ez-block="actions"]{order:6}',
    'body[data-ez-tab="2"] [data-ez-block="lang"]{order:7}',
    '[data-ez-block="clear"]{width:100%;padding:7px!important;font-size:10.5px!important;border-radius:9px!important}',
    '[data-ez-cache="1"]{display:none!important}',
    '[data-ez-hide="1"]{display:none!important}',
    // Los bloques .glass hijos directos del panel tienen display:flex!important
    // (linea de .panel-in > .glass); hace falta esta especificidad para ocultarlos.
    '.panel-in > .glass[data-ez-hide="1"]{display:none!important}',
    '[data-ez-block="folder"] p,[data-ez-block="prompts"] p{display:none!important}',
    '.glow:after,.run-btn:after{display:none!important;animation:none!important;background:none!important}',

    /* ---------- tabs ---------- */
    '#ez-tabs{order:0;position:sticky;top:0;z-index:30;display:flex;gap:4px;padding:3px;margin:0 0 2px;border-radius:11px;background:rgba(10,10,12,.94);border:1px solid rgba(255,255,255,.08);backdrop-filter:blur(10px)}',
    '.ez-tab{flex:1;border:0;border-radius:8px;padding:7px 4px;font:600 11px/1 system-ui,-apple-system,sans-serif;color:#a1a1aa;background:transparent;cursor:pointer;transition:background .15s,color .15s}',
    '.ez-tab.is-active{background:linear-gradient(135deg,#cc0000,#7a0000);color:#fff;box-shadow:0 4px 14px -6px #f00c}',

    /* ---------- glass card + section labels ---------- */
    '.panel-in > .glass{padding:8px!important;border-radius:14px!important;display:flex!important;flex-direction:column!important;gap:6px!important}',
    '.panel-in > .glass > *{margin:0!important}',
    '.panel-in > .glass span[class*="uppercase"]{font-size:8px!important;line-height:1.1!important;letter-spacing:.08em!important;margin-bottom:2px!important}',
    '.panel-in > .glass p{display:none!important}',

    /* ---------- buttons compact ---------- */
    '.panel-in .seg{padding:4px 6px!important;font-size:10.5px!important;border-radius:8px!important;min-height:0!important}',
    '.panel-in .seg span{font-size:inherit!important}',

    /* mode: 4 en una sola linea, sin emojis */
    '[data-ez-sec="mode"] > div{display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:3px!important}',
    '[data-ez-sec="mode"] button{flex-direction:row!important;align-items:center!important;justify-content:center!important;gap:0!important;padding:5px 2px!important;min-height:0!important}',
    '[data-ez-sec="mode"] button > span:first-child{display:none!important}',
    '[data-ez-sec="mode"] button > span:last-child{font-size:8px!important;line-height:1.05!important;text-align:center!important;white-space:nowrap!important;letter-spacing:-.2px!important}',

    /* model / aspect / quality: one-line wraps */
    '[data-ez-sec="model"] .grid,[data-ez-sec="aspect"] .grid,[data-ez-sec="quality"] .grid{display:flex!important;flex-wrap:wrap!important;gap:3px!important}',
    '[data-ez-sec="model"] .grid > *{flex:1 1 30%}',
    '[data-ez-sec="aspect"] .grid > *{flex:1 1 17%}',
    '[data-ez-sec="quality"] .grid > *{flex:1 1 20%}',
    '[data-ez-sec="quality"] span[class*="rounded-full"]{display:none!important}',

    /* outputs */
    '[data-ez-sec="outputs"]{gap:3px!important}',
    '[data-ez-sec="outputs"] input[type="range"]{height:6px!important;margin:2px 0!important}',
    '[data-ez-sec="outputs"] .range-slider::-webkit-slider-thumb{width:14px!important;height:14px!important}',
    '[data-ez-sec="outputs"] .flex.justify-between button{font-size:10px!important;padding:0!important}',

    /* toggles */
    '.panel-in label.field{padding:5px 8px!important;border-radius:9px!important;min-height:0!important}',
    '.panel-in label.field span[class*="text-[10px]"]{display:none!important}',
    '.panel-in label.field span[class*="text-xs"]{font-size:10.5px!important}',

    /* barras decorativas vacias */
    '.panel-in [aria-hidden="true"] .h-1,.panel-in div[aria-hidden="true"].h-1{display:none!important}',

    /* advanced (tab 2) */
    '[data-ez-sec="misc"]{gap:4px!important}',
    '[data-ez-sec="misc"] button{min-height:0!important}',
    '[data-ez-sec="misc"] .grid > *{padding:5px 6px!important;font-size:10.5px!important}',
    '[data-ez-sec="wait"] input{padding:4px 8px!important;font-size:11px!important;border-radius:8px!important}',
    '[data-ez-sec="misc"] button.glow.grid.h-16{height:52px!important;width:52px!important}',

    /* ---------- prompts ---------- */
    '[data-ez-block="prompts"] textarea{font-size:11.5px!important;padding:7px 10px!important;min-height:74px!important;height:74px!important;border-radius:10px!important}',
    '[data-ez-block="prompts"] > div > span[class*="uppercase"]{font-size:8px!important}',
    '[data-ez-block="prompts"] button.ez-clear{padding:6px!important;font-size:10.5px!important;border-radius:9px!important;margin-top:4px!important}',

    /* ---------- queue (app) ---------- */
    '[data-ez-block="queue"]{gap:3px!important}',
    '[data-ez-block="queue"] > div{max-height:150px!important;overflow-y:auto!important;gap:3px!important}',
    '[data-ez-block="queue"] > div > div{padding:4px 8px!important;font-size:10.5px!important;border-radius:8px!important;gap:2px!important}',

    /* ---------- run ---------- */
    '[data-ez-block="run"]{padding:9px 12px!important;border-radius:10px!important;font-size:12px!important;position:sticky;bottom:2px;z-index:20}',
    '[data-ez-block="run"] span{font-size:12px!important;line-height:1!important}',
    '#ezehflow-continue-btn{padding:9px 10px!important;font-size:12px!important;border-radius:10px!important}',

    /* ---------- folder / actions / language ---------- */
    '[data-ez-block="folder"] input{padding:6px 8px!important;font-size:11px!important;border-radius:9px!important}',
    '[data-ez-block="folder"] button{padding:6px 8px!important;font-size:10.5px!important;border-radius:9px!important}',
    '[data-ez-block="actions"] button{padding:6px 4px!important;font-size:10px!important}',
    '[data-ez-block="lang"]{padding:7px 10px!important;font-size:11px!important;border-radius:9px!important}',

    /* ---------- console tab ---------- */
    '#ez-console{position:fixed;left:6px;right:6px;top:42px;bottom:6px;z-index:60;display:none;flex-direction:column;background:#070708;border:1px solid #26262a;border-radius:12px;overflow:hidden;font:10.5px/1.45 ui-monospace,Consolas,monospace}',
    'body[data-ez-tab="3"] #ez-console{display:flex}',
    'body[data-ez-tab="3"] .panel-in > *:not(#ez-tabs){display:none!important}',
    '#ez-console-head{display:flex;gap:4px;align-items:center;padding:5px 6px;border-bottom:1px solid #26262a;background:#0d0d10}',
    '#ez-console-head strong{font:600 10px system-ui,sans-serif;color:#d4d4d8;margin-right:auto;letter-spacing:.08em}',
    '.ez-cbtn{border:1px solid #2f2f35;background:#17171b;color:#d4d4d8;border-radius:7px;padding:4px 8px;font:600 9.5px system-ui,sans-serif;cursor:pointer}',
    '.ez-cbtn:hover{background:#232329}',
    '#ez-console-log{flex:1;overflow:auto;padding:4px 6px;white-space:pre-wrap;word-break:break-word;color:#c8c8cf}',
    '#ez-console-foot{display:flex;flex-direction:column;gap:5px;padding:6px;border-top:1px solid #26262a;background:#0d0d10}',
    '[data-ez-report-orig]{display:none!important}',
    '[data-ez-report-panel]{display:none!important}',
    '#ez-report-btn{width:100%;padding:8px;font-size:10.5px;font-weight:600;border-radius:9px;border:1px solid #3a3a40;background:#17171b;color:#d4d4d8;cursor:pointer}',
    '#ez-report-btn:hover{background:#222228}',
    '#ez-report-mirror{display:none;padding:7px;border:1px solid #5b2020;border-radius:9px;background:#2a1214;color:#f0a0a0;font-size:10px;line-height:1.35;word-break:break-word;white-space:pre-wrap}',
    '.ez-cl{padding:1px 0;border-bottom:1px solid #ffffff08}',
    '.ez-cl .t{color:#71717a;margin-right:4px}',
    '.ez-cl .s{color:#3f3f46;margin-right:4px}',
    '.ez-cl.warn{color:#fbbf24}',
    '.ez-cl.error{color:#f87171}',
    '.ez-empty{color:#52525b;padding:8px}',

    /* ---------- bloques retirados + caja Personaje ---------- */
    '[data-ez-removed="1"]{display:none!important}',
    '#ez-ref-row{display:flex;gap:10px;align-items:flex-start}',
    '#ez-ref-row>*{flex:1 1 0;min-width:0}',
    '#ez-lang-row{display:flex;flex-direction:column;gap:3px;padding:6px;border-bottom:1px solid #26262a;background:#0d0d10}',
    '#ez-lang-row label{font:600 9px system-ui,sans-serif;letter-spacing:.1em;text-transform:uppercase;color:#71717a}',
    '#ez-lang-row select{width:100%;background:#17171b;color:#d4d4d8;border:1px solid #2f2f35;border-radius:8px;padding:6px 8px;font:500 11px system-ui,sans-serif}',
    '#ez-char-box #ez-char-status{display:block;font-size:9px;line-height:1.2;color:#71717a;margin-top:1px}',
    '#ez-char-slot.is-on{border:1px solid #ef4444!important;box-shadow:0 0 0 1px #ef4444 inset,0 0 10px -2px #ef444488!important;color:#fecaca!important}',
    '.waiting-banner-row{display:flex!important;align-items:center!important;gap:8px!important;width:100%!important}',
    '.waiting-banner-text{flex:1 1 auto!important;min-width:0!important}',
    '.waiting-banner-eta{margin-left:auto!important;flex:0 0 auto!important;text-align:right!important;white-space:nowrap!important;font-variant-numeric:tabular-nums!important}'
  ];

  var style = document.createElement('style');
  style.id = 'ezehflow-design-css';
  style.textContent = css.join('\n');
  document.head.appendChild(style);

  /* ---------------- state ---------------- */
  var activeTab = '1';
  try {
    var saved = sessionStorage.getItem('ezehTab');
    if (saved === '2' || saved === '3') activeTab = saved;
  } catch (e) {}

  /* ---------------- tabs ---------------- */
  function setTab(tab) {
    activeTab = tab;
    document.body.dataset.ezTab = tab;
    try { sessionStorage.setItem('ezehTab', tab); } catch (e) {}
    var btns = document.querySelectorAll('.ez-tab');
    for (var i = 0; i < btns.length; i++) {
      btns[i].classList.toggle('is-active', btns[i].dataset.tab === tab);
    }
    if (tab === '3') renderConsole(true);
    try { apply(); } catch (e) {}
  }

  function ensureTabs(panel) {
    var bar = document.getElementById('ez-tabs');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'ez-tabs';
      bar.innerHTML = '<button type="button" class="ez-tab" data-tab="1">Configuración</button>' +
                      '<button type="button" class="ez-tab" data-tab="2">Fila y Carpeta</button>' +
                      '<button type="button" class="ez-tab" data-tab="3">Consola</button>';
      bar.addEventListener('click', function (ev) {
        var b = ev.target.closest('.ez-tab');
        if (b) setTab(b.dataset.tab);
      });
      panel.insertBefore(bar, panel.firstChild);
      bar.querySelectorAll('.ez-tab').forEach(function (b) {
        b.classList.toggle('is-active', b.dataset.tab === activeTab);
      });
    }
    document.body.dataset.ezTab = activeTab;
  }

  /* ---------------- console ---------------- */
  var consoleLogEl = null;
  var consolePlain = '';
  var consoleSig = '';

  function esc(s) {
    return String(s).replace(/[&<>]/g, function (c) {
      return c === '&' ? '&amp;' : c === '<' ? '&lt;' : '&gt;';
    });
  }

  function ensureConsole() {
    if (document.getElementById('ez-console')) {
      consoleLogEl = document.getElementById('ez-console-log');
      return;
    }
    var box = document.createElement('div');
    box.id = 'ez-console';
    box.innerHTML = '<div id="ez-console-head"><strong>CONSOLA</strong>' +
      '<button type="button" class="ez-cbtn" id="ez-c-copy">Copiar todo</button>' +
      '<button type="button" class="ez-cbtn" id="ez-c-clear">Limpiar</button></div>' +
      '<div id="ez-console-log"><div class="ez-empty">Sin registros todavía.</div></div>' +
      '<div id="ez-console-foot"></div>';
    document.body.appendChild(box);
    consoleLogEl = document.getElementById('ez-console-log');
    document.getElementById('ez-c-copy').addEventListener('click', function () {
      var btn = this;
      var ok = function () {
        btn.textContent = 'Copiado';
        setTimeout(function () { btn.textContent = 'Copiar todo'; }, 1200);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(consolePlain).then(ok, ok);
      } else {
        var ta = document.createElement('textarea');
        ta.value = consolePlain;
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        ta.remove();
        ok();
      }
    });
    document.getElementById('ez-c-clear').addEventListener('click', function () {
      try { chrome.storage.local.set({ ez_log_content: [], ez_log_worker: [] }); } catch (e) {}
      consoleSig = '';
      consolePlain = '';
      renderConsole(true);
    });
  }

  function renderConsole(force) {
    if (!consoleLogEl || document.body.dataset.ezTab !== '3') return;
    chrome.storage.local.get(['ez_log_content', 'ez_log_worker']).then(function (r) {
      var list = (r.ez_log_content || []).concat(r.ez_log_worker || []);
      list.sort(function (a, b) { return a.t - b.t; });
      var sig = list.length + '|' + (list.length ? list[list.length - 1].t : 0);
      if (!force && sig === consoleSig) return;
      consoleSig = sig;
      var tail = list.slice(-500);
      var atBottom = consoleLogEl.scrollTop + consoleLogEl.clientHeight >= consoleLogEl.scrollHeight - 40;
      var rows = [];
      var plain = [];
      for (var i = 0; i < tail.length; i++) {
        var e = tail[i];
        var d = new Date(e.t);
        var ts = String(d.getHours()).padStart(2, '0') + ':' +
                 String(d.getMinutes()).padStart(2, '0') + ':' +
                 String(d.getSeconds()).padStart(2, '0') + '.' +
                 String(d.getMilliseconds()).padStart(3, '0');
        var lvl = e.lvl === 'error' ? 'error' : e.lvl === 'warn' ? 'warn' : 'info';
        rows.push('<div class="ez-cl ' + lvl + '"><span class="t">' + ts + '</span><span class="s">' +
                  esc(e.src) + '</span>' + esc(e.msg) + '</div>');
        plain.push(ts + ' [' + e.src + '] ' + e.msg);
      }
      consolePlain = plain.join('\n');
      consoleLogEl.innerHTML = rows.join('') || '<div class="ez-empty">Sin registros todavía.</div>';
      if (atBottom) consoleLogEl.scrollTop = consoleLogEl.scrollHeight;
    }).catch(function () {});
  }

  /* ---------------- classification ---------------- */
  function sectionTab(el) {
    var t = (el.textContent || '').toUpperCase();
    if (t.indexOf('MODO') !== -1 || t.indexOf('GENERATION MODE') !== -1) return ['1', 'mode'];
    if (t.indexOf('MODELO') !== -1 || t.indexOf('MODEL') !== -1) return ['1', 'model'];
    if (t.indexOf('RELACI') !== -1 || t.indexOf('ASPECT') !== -1) return ['1', 'aspect'];
    if (t.indexOf('CALIDAD') !== -1 || t.indexOf('QUALITY') !== -1) return ['1', 'quality'];
    if (t.indexOf('SALIDAS') !== -1 || t.indexOf('OUTPUTS') !== -1) return ['1', 'outputs'];
    if (t.indexOf('IMAGEN DE REFERENCIA') !== -1 || t.indexOf('REFERENCE IMAGE') !== -1) return ['1', 'ref'];
    if (/DURACI|DURATION/.test(t)) return ['1', 'duration'];
    if (/M[EÉ]TODO|METHOD/.test(t)) return ['1', 'method'];
    if (/ESPERA|REINTENT|RANDOM WAIT|RETR/.test(t)) return ['1', 'timing'];

    return ['2', 'misc'];
  }

  function classify(panel) {
    var kids = panel.children;
    for (var i = 0; i < kids.length; i++) {
      var el = kids[i];
      if (el.id === 'ez-tabs') continue;
      if (el.tagName === 'HEADER' || el.classList.contains('account-panel')) continue;
      if (el.id === 'ez-queue-grid') continue;
      if (el.classList.contains('ez-clear')) continue;
      if (el.classList.contains('glass')) {
        el.dataset.ezBlock = 'settings';
        for (var j = 0; j < el.children.length; j++) {
          var sec = el.children[j];
          if (sec.id === 'ez-char-box' || sec.id === 'ez-ref-row' || sec.id === 'ez-queue-grid') continue;
          var conf = sectionTab(sec);
          if (sec.dataset.ezp !== conf[0]) sec.dataset.ezp = conf[0];
          if (sec.dataset.ezSec !== conf[1]) sec.dataset.ezSec = conf[1];
          var st = (sec.textContent || '').toUpperCase();
          if (/EMPAREJAR 1:1|PAIR 1:1|MATCH 1:1/.test(st)) {
            if (sec.dataset.ezHide !== '1') sec.dataset.ezHide = '1';
          }
        }

        continue;
      }
      var txt = (el.textContent || '').toUpperCase().trim();
      if (el.querySelector('textarea')) { el.dataset.ezp = '2'; el.dataset.ezBlock = 'prompts'; }
      else if (el.classList.contains('run-btn')) { el.dataset.ezp = '2'; el.dataset.ezBlock = 'run'; }
      else if (el.tagName === 'SELECT') { el.dataset.ezp = '2'; el.dataset.ezBlock = 'lang'; }
      else if (el.id === 'continue-list-wrapper') { el.dataset.ezp = '2'; el.dataset.ezBlock = 'continue'; }
      else if (txt.indexOf('CARPETA') !== -1 || txt.indexOf('FOLDER') !== -1) { el.dataset.ezp = '2'; el.dataset.ezBlock = 'folder'; }
      else if (/^(COLA|QUEUE|FILA|ROW)/.test(txt)) { el.dataset.ezp = '2'; el.dataset.ezBlock = 'queue'; }
      else { el.dataset.ezp = '2'; el.dataset.ezBlock = 'actions'; }
    }
  }

  /* "Descargas por prompt" sobra: el usuario elige salidas, no descargas.
     Como el selector queda oculto, se fija solo en "todas las salidas". */
  var DL_LABEL = /^(descargas? por prompt|downloads? (per|por|pro) prompt|download per prompt|t[ée]l[ée]chargements? par prompt|загрузок на промпт|التنزيلات لكل موجه|每个提示的下载数|每個提示的下載數|プロンプトごとのダウンロード数|프롬프트당 다운로드 수|प्रति प्रॉम्प्ट डाउनलोड)$/i;
  function hideDownloadsBlock(block) {
    if (!block) return;
    var buttons = block.querySelectorAll('button');
    if (buttons.length) {
      var last = buttons[buttons.length - 1];
      if (!last.disabled && !last.classList.contains('seg-active')) {
        try { last.click(); } catch (e) {}
      }
    }
    if (block.dataset.ezHide !== '1') block.dataset.ezHide = '1';
  }
  function hideDownloads(panel) {
    var spans = panel.querySelectorAll('span');
    for (var i = 0; i < spans.length; i++) {
      var txt = (spans[i].textContent || '').replace(/\s+/g, ' ').trim();
      if (!DL_LABEL.test(txt)) continue;
      var block = spans[i];
      while (block.parentElement && !block.parentElement.classList.contains('glass')) block = block.parentElement;
      if (block.parentElement && block.parentElement.classList.contains('glass')) hideDownloadsBlock(block);
      return;
    }
    // Fallback por posicion: el bloque que aparece entre "Salidas" y
    // "Espera/Reintentos" cuando hay mas de una salida es el de descargas.
    var out = panel.querySelector('[data-ez-sec="outputs"]');
    if (out && out.parentElement) {
      var next = out.nextElementSibling;
      if (next && next.dataset.ezSec === 'misc' &&
          next.nextElementSibling && next.nextElementSibling.dataset.ezSec === 'timing') {
        hideDownloadsBlock(next);
      }
    }
  }

  /* "Limpiar prompts": bajo el textarea en tab 1, bajo la cola en tab 2 */
  function moveClear(panel) {
    var textarea = panel.querySelector('textarea');
    if (!textarea) return;
    var block = textarea.parentElement;
    if (!block) return;
    var btns = panel.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
      var txt = (btns[i].textContent || '').toLowerCase();
      if (txt.indexOf('limpiar prompts') !== -1 || txt.indexOf('clear prompts') !== -1) {
        var btn = btns[i];
        btn.classList.add('ez-clear');
        var target = activeTab === '2' ? panel : block;
        if (btn.parentElement !== target) target.appendChild(btn);
        if (activeTab === '2') btn.dataset.ezBlock = 'clear';
        else delete btn.dataset.ezBlock;
        break;
      }
    }
  }

  /* "Limpiar caché" -> cabecera de la Consola (se oculta el original y se reenvía el click) */
  function moveCache(panel) {
    var host = panel.querySelector('[data-ez-block="actions"]');
    if (!host) return;
    var ab = host.querySelectorAll('button');
    var cache = null;
    for (var i = 0; i < ab.length; i++) {
      if (/cach|cache/i.test(ab[i].textContent || '')) { cache = ab[i]; break; }
    }
    if (!cache && ab.length) cache = ab[0];
    if (!cache) return;
    cache.dataset.ezCache = '1';
    var head = document.getElementById('ez-console-head');
    if (!head) return;
    var clone = document.getElementById('ez-c-cache');
    if (!clone) {
      clone = document.createElement('button');
      clone.type = 'button';
      clone.className = 'ez-cbtn';
      clone.id = 'ez-c-cache';
      clone.addEventListener('click', function () {
        var live = panel.querySelector('[data-ez-cache="1"]');
        if (live) live.click();
      });
      head.appendChild(clone);
    }
    var label = (cache.textContent || '').replace(EMOJI_RE, '').trim() || 'Limpiar caché';
    if (clone.textContent !== label) clone.textContent = label;
  }

  /* "Reportar error" -> pie de la Consola (proxy + espejo del reporte) */
  function moveReport(panel) {
    var foot = document.getElementById('ez-console-foot');
    if (!foot) return;
    var orig = null, btns = panel.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
      if ((btns[i].textContent || '').indexOf('⚠') !== -1) { orig = btns[i]; break; }
    }
    if (!orig) return;
    if (!orig.dataset.ezReportOrig) orig.dataset.ezReportOrig = '1';
    var btn = document.getElementById('ez-report-btn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'ez-report-btn';
      btn.addEventListener('click', function () {
        var all = panel.querySelectorAll('button'), b = null;
        for (var k = 0; k < all.length; k++) {
          if ((all[k].textContent || '').indexOf('⚠') !== -1) { b = all[k]; break; }
        }
        if (b) b.click();
      });
      foot.appendChild(btn);
    }
    var label = (orig.textContent || '').trim() || '⚠ Reportar error';
    if (btn.textContent !== label) btn.textContent = label;
    var box = panel.querySelector('[class*="border-red-500/20"]');
    var mir = document.getElementById('ez-report-mirror');
    if (box) {
      if (!box.dataset.ezReportPanel) box.dataset.ezReportPanel = '1';
      var txt = (box.textContent || '').trim();
      if (!mir) { mir = document.createElement('div'); mir.id = 'ez-report-mirror'; foot.insertBefore(mir, btn); }
      if (mir.textContent !== txt) mir.textContent = txt;
      mir.style.display = 'block';
    } else if (mir) {
      mir.style.display = 'none';
    }
  }

  /* keep the language selector out of the hidden header (tab 2) */
  function moveLang(panel) {
    var sel = panel.querySelector('select');
    if (sel && sel.parentElement !== panel) panel.appendChild(sel);
  }

  function hideBits(panel) {
    var btns = panel.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
      var t = (btns[i].textContent || '').toLowerCase();
      if (t.indexOf('escanear personajes') !== -1 || t.indexOf('scan characters') !== -1) {
        if (btns[i].dataset.ezHide !== '1') btns[i].dataset.ezHide = '1';
      }
    }
    var labels = panel.querySelectorAll('label');
    for (var k = 0; k < labels.length; k++) {
      var lt = (labels[k].textContent || '').toLowerCase();
      if (lt.indexOf('emparejar 1:1') !== -1 || lt.indexOf('pair 1:1') !== -1) {
        if (labels[k].dataset.ezHide !== '1') labels[k].dataset.ezHide = '1';
      }
    }
  }

  var EMOJI_RE = /[\uD800-\uDFFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F]/g;

  function stripEmojis(panel) {
    var mode = panel.querySelector('[data-ez-sec="mode"]');
    if (!mode) return;
    var spans = mode.querySelectorAll('button > span:first-child');
    for (var i = 0; i < spans.length; i++) {
      var sp = spans[i];
      if (!sp.children.length && EMOJI_RE.test(sp.textContent || '')) sp.style.display = 'none';
      EMOJI_RE.lastIndex = 0;
    }
    var walk = document.createTreeWalker(mode, NodeFilter.SHOW_TEXT, null, false);
    var n;
    while ((n = walk.nextNode())) {
      var t = n.nodeValue || '';
      if (!EMOJI_RE.test(t)) continue;
      EMOJI_RE.lastIndex = 0;
      var clean = t.replace(EMOJI_RE, '').replace(/\s{2,}/g, ' ').trim();
      if (clean !== t) n.nodeValue = clean;
    }
  }

  var thinLogged = false;
  function logThinBar(panel) {
    if (thinLogged) return;
    var ta = panel.querySelector('textarea');
    if (!ta) return;
    var top = ta.parentElement.getBoundingClientRect().top, hits = [];
    var all = panel.querySelectorAll('*');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.closest('#ez-tabs,#ez-console') || el.tagName === 'TEXTAREA') continue;
      var r = el.getBoundingClientRect(), cs = getComputedStyle(el);
      if (cs.display === 'none' || r.height <= 0 || r.width < 120) continue;
      if (r.bottom > top + 2 || r.bottom < top - 90) continue;
      hits.push(el.tagName + '.' + String(el.className).slice(0, 45) + ' h' + Math.round(r.height) + ' w' + Math.round(r.width) + ' ' + cs.backgroundColor + ' «' + (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 18) + '»');
    }
    thinLogged = true;
    if (!hits.length) return;
    var desc = 'gap: ' + hits.slice(0, 14).join(' | ');
    try {
      chrome.storage.local.get('ez_log_content').then(function (res) {
        var arr = Array.isArray(res.ez_log_content) ? res.ez_log_content : [];
        arr.push({ t: Date.now(), src: 'popup', lvl: 'info', msg: '[bar] ' + desc });
        return chrome.storage.local.set({ ez_log_content: arr });
      });
    } catch (e) {}
  }

  /* ---------------- bloques retirados (personaje viejo / encadenar / aviso) ---------------- */
  var CHAR_LABEL_RE = /^(personaje|character|personnage|charakter)\s*\(/i;
  var AUTO_LABELS = ['encadenar resultados', 'chain outputs', 'enchaîner les résultats', 'ergebnisse verketten', 'concatena i risultati', 'encadear resultados'];

  function hideRemoved(panel) {
    var groups = panel.querySelectorAll('div[class~="space-y-1.5"]');
    for (var i = 0; i < groups.length; i++) {
      var g = groups[i];
      if (g.id === 'ez-char-box' || g.querySelector('input[type="file"]')) continue;
      var lab = g.querySelector('span');
      if (lab && CHAR_LABEL_RE.test((lab.textContent || '').trim())) g.dataset.ezRemoved = '1';
    }
    var labels = panel.querySelectorAll('label');
    for (var k = 0; k < labels.length; k++) {
      var lt = (labels[k].textContent || '').toLowerCase(), hit = false;
      for (var j = 0; j < AUTO_LABELS.length; j++) {
        if (lt.indexOf(AUTO_LABELS[j]) !== -1) { hit = true; break; }
      }
      if (!hit) continue;
      var inp = labels[k].querySelector('input[type="checkbox"]');
      if (inp && inp.checked && !inp.disabled && inp.dataset.ezUncheck !== '1') {
        inp.dataset.ezUncheck = '1';
        inp.click();
      }
      labels[k].dataset.ezRemoved = '1';
    }
    var hint = document.querySelector('.waiting-banner-hint');
    if (hint && /reintenta solo|is retried/i.test(hint.textContent || '')) hint.dataset.ezRemoved = '1';
  }

  /* ---------------- caja "Personaje" (elige una imagen del proyecto) ---------------- */
  var charBox = null, charSlot = null, charStatus = null, charClear = null, charSelected = null, charLoaded = false;

  function charSetStatus(txt) {
    if (charStatus && charStatus.textContent !== txt) charStatus.textContent = txt;
  }

  function paintChar() {
    if (!charSlot) return;
    var on = !!charSelected;
    charSlot.classList.toggle('is-on', on);
    charSlot.textContent = on ? '✓' : '+';
    charSlot.title = on ? 'Personaje elegido — clic para cambiarlo' : 'Elegir una imagen del proyecto';
    if (charClear) charClear.style.display = on ? 'block' : 'none';
    charSetStatus(on ? 'Personaje aplicado a cada prompt' : 'Elige una imagen de tu proyecto');
  }

  function flowCandidates(cb) {
    try {
      chrome.tabs.query({}, function (tabs) {
        var list = [];
        (tabs || []).forEach(function (t) {
          var u;
          try { u = new URL(t.url); } catch (e) { return; }
          var isFlow = u.hostname === 'flow.google.com' || (u.hostname === 'labs.google' && u.pathname.indexOf('flow') >= 0);
          if (isFlow) list.push(t);
        });
        list.sort(function (a, b) {
          return (!!b.active - !!a.active) || ((b.lastAccessed || 0) - (a.lastAccessed || 0));
        });
        cb(list);
      });
    } catch (e) { cb([]); }
  }

  function flowTab(cb) {
    flowCandidates(function (list) {
      if (!list.length) return cb(null);
      var i = 0;
      (function next() {
        if (i >= list.length) return cb(list[0]);
        var t = list[i++];
        try {
          chrome.tabs.sendMessage(t.id, { type: 'EZ_PING' }, function (res) {
            if (!chrome.runtime.lastError && res && res.ok === true) return cb(t);
            next();
          });
        } catch (e) { next(); }
      })();
    });
  }

  // ponytail: dynamic import() from an executeScript-injected script is blocked by
  // Chrome, so a dead driver is revived by injecting the real loader; if that does
  // not answer either, reload the tab (same fallback the service worker uses).
  function ensureFlow(tab, done) {
    function ping(cb) {
      try {
        chrome.tabs.sendMessage(tab.id, { type: 'EZ_PING' }, function (res) {
          cb(!chrome.runtime.lastError && !!res && res.ok === true);
        });
      } catch (e) { cb(false); }
    }
    function poll(n, cb) {
      ping(function (ok) {
        if (ok) return cb(true);
        if (n <= 0) return cb(false);
        setTimeout(function () { poll(n - 1, cb); }, 250);
      });
    }
    function reloadThen(cb) {
      charSetStatus('Recargando la pestaña de Flow…');
      var settled = false;
      function finish(ok) {
        if (settled) return;
        settled = true;
        try { chrome.tabs.onUpdated.removeListener(onUp); } catch (e) {}
        cb(ok);
      }
      function onUp(id, info) {
        if (id !== tab.id || info.status !== 'complete') return;
        poll(24, finish);
      }
      try {
        chrome.tabs.onUpdated.addListener(onUp);
        chrome.tabs.reload(tab.id);
        setTimeout(function () { poll(4, finish); }, 20000);
      } catch (e) {
        console.warn('[EzehFlow] reload failed:', e && (e.message || e));
        finish(false);
      }
    }
    ping(function (ok) {
      if (ok) return done(null);
      try {
        chrome.scripting.executeScript(
          { target: { tabId: tab.id }, files: ['assets/index.ts-loader-DXTKhdv1.js'] },
          function () {
            if (chrome.runtime.lastError) {
              console.warn('[EzehFlow] inject failed:', chrome.runtime.lastError.message);
            }
            poll(8, function (live) {
              if (live) return done(null);
              reloadThen(function (ok2) { done(ok2 ? null : 'no-receiver'); });
            });
          }
        );
      } catch (e) {
        console.warn('[EzehFlow] inject threw:', e && (e.message || e));
        reloadThen(function (ok2) { done(ok2 ? null : 'no-receiver'); });
      }
    });
  }

  function pickInFlow(tab, retried) {
    var watch = setTimeout(function () {
      if (charSlot.dataset.ezBusy !== '1') return;
      charSlot.dataset.ezBusy = '0';
      charSetStatus('No se recibió ningún clic. Probá de nuevo.');
    }, 95000);
    function finish() { clearTimeout(watch); charSlot.dataset.ezBusy = '0'; }
    try {
      chrome.tabs.sendMessage(tab.id, { type: 'EZ_PICK_CHARACTER' }, function (res) {
        if (chrome.runtime.lastError || !res) {
          if (!retried) {
            charSetStatus('Activando la extensión en esta pestaña…');
            return ensureFlow(tab, function (err) {
              if (err) {
                finish();
                charSetStatus('No se pudo conectar con Flow. Probá de nuevo.');
                return;
              }
              pickInFlow(tab, true);
            });
          }
          finish();
          charSetStatus('No se pudo seleccionar. Probá de nuevo.');
          return;
        }
        finish();
        if (!res.ok) {
          charSetStatus(res.reason === 'cancelled' ? 'Selección cancelada' : 'No se pudo seleccionar. Probá de nuevo.');
          return;
        }
        charSelected = res.src;
        try { chrome.storage.local.set({ ez_char_src: res.src }); } catch (e) {}
        paintChar();
      });
      charSetStatus('Haz clic en la imagen del proyecto…');
    } catch (e) {
      finish();
      charSetStatus('No se pudo conectar con Flow. Probá de nuevo.');
    }
  }

  function buildCharBox() {
    var box = document.createElement('div');
    box.id = 'ez-char-box';
    box.className = 'space-y-1.5';
    var label = document.createElement('span');
    label.className = 'text-[10px] font-medium uppercase tracking-[0.12em] text-zinc-400';
    label.textContent = 'Personaje';
    var row = document.createElement('div');
    row.className = 'flex flex-wrap gap-2';
    var wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;display:inline-block';
    charSlot = document.createElement('button');
    charSlot.type = 'button';
    charSlot.id = 'ez-char-slot';
    charSlot.className = 'glow grid h-16 w-16 place-items-center rounded-xl border border-dashed border-white/15 bg-white/[0.03] text-xl text-zinc-400 transition-transform hover:scale-105 hover:bg-white/[0.06]';
    charSlot.textContent = '+';
    charClear = document.createElement('button');
    charClear.type = 'button';
    charClear.id = 'ez-char-clear';
    charClear.title = 'Quitar personaje';
    charClear.textContent = '×';
    charClear.style.cssText = 'display:none;position:absolute;right:-5px;top:-5px;width:18px;height:18px;border-radius:999px;border:0;background:#000c;color:#fff;font:11px/1 system-ui;cursor:pointer;z-index:2';
    wrap.appendChild(charSlot);
    wrap.appendChild(charClear);
    row.appendChild(wrap);
    charStatus = document.createElement('span');
    charStatus.id = 'ez-char-status';
    box.appendChild(label);
    box.appendChild(row);
    box.appendChild(charStatus);

    charSlot.addEventListener('click', function () {
      if (charSlot.dataset.ezBusy === '1') return;
      charSlot.dataset.ezBusy = '1';
      charSetStatus('Buscando la pestaña de Google Flow…');
      flowTab(function (tab) {
        if (!tab) {
          charSlot.dataset.ezBusy = '0';
          charSetStatus('Abre Google Flow y vuelve a intentar');
          return;
        }
        try { chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
        charSetStatus('Preparando la pestaña de Flow…');
        ensureFlow(tab, function (err) {
          if (err) {
            charSlot.dataset.ezBusy = '0';
            charSetStatus('No se pudo conectar con Flow. Probá de nuevo.');
            return;
          }
          pickInFlow(tab, false);
        });
      });
    });

    charClear.addEventListener('click', function (ev) {
      ev.stopPropagation();
      charSelected = null;
      try { chrome.storage.local.remove('ez_char_src'); } catch (e) {}
      paintChar();
      flowTab(function (tab) {
        if (!tab) return;
        try { chrome.tabs.sendMessage(tab.id, { type: 'EZ_CLEAR_CHARACTER' }, function () {}); } catch (e) {}
      });
    });

    paintChar();
    return box;
  }

  function applyCharBox(panel) {
    var ref = panel.querySelector('[data-ez-sec="ref"]:not(#ez-ref-row)');
    if (!ref) return;
    if (!charBox) charBox = buildCharBox();
    charBox.dataset.ezp = '1';
    var row = document.getElementById('ez-ref-row');
    var host = (row && row.contains(ref)) ? row.parentElement : ref.parentElement;
    if (!host) return;
    if (!row) {
      row = document.createElement('div');
      row.id = 'ez-ref-row';
      row.dataset.ezp = '1';
    }
    if (row.parentElement !== host) host.insertBefore(row, row.contains(ref) ? null : ref);
    if (ref.parentElement !== row || row.firstElementChild !== ref) row.insertBefore(ref, row.firstChild);
    if (charBox.parentElement !== row) row.appendChild(charBox);
    paintChar();
  }

  function loadChar() {
    if (charLoaded) return;
    charLoaded = true;
    try {
      chrome.storage.local.get('ez_char_src').then(function (r) {
        charSelected = (r && r.ez_char_src) || null;
        paintChar();
      }).catch(function () {});
    } catch (e) {}
  }

  /* ---------------- idioma: arriba de la consola (proxy del select real) ---------------- */
  function applyLangConsole(panel) {
    var box = document.getElementById('ez-console');
    var log = document.getElementById('ez-console-log');
    if (!box || !log) return;
    var orig = panel.querySelector('select');
    if (orig) orig.style.display = 'none';
    var row = document.getElementById('ez-lang-row');
    if (!row) {
      row = document.createElement('div');
      row.id = 'ez-lang-row';
      var lab = document.createElement('label');
      lab.htmlFor = 'ez-lang-copy';
      lab.textContent = 'Idioma';
      row.appendChild(lab);
      box.insertBefore(row, log);
    }
    var sel = document.getElementById('ez-lang-copy');
    if (!sel) {
      sel = document.createElement('select');
      sel.id = 'ez-lang-copy';
      row.appendChild(sel);
      sel.addEventListener('change', function () {
        var src = document.querySelector('.panel-in select');
        if (!src) return;
        try {
          var setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set;
          setter.call(src, sel.value);
        } catch (e) { src.value = sel.value; }
        src.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
    if (orig) {
      if (sel.options.length !== orig.options.length) {
        sel.innerHTML = '';
        for (var i = 0; i < orig.options.length; i++) {
          var o = document.createElement('option');
          o.value = orig.options[i].value;
          o.textContent = orig.options[i].textContent;
          sel.appendChild(o);
        }
      }
      if (sel.value !== orig.value) sel.value = orig.value;
    }
    if (row.parentElement !== box || row.nextSibling !== log) box.insertBefore(row, log);
  }

  var gateAt = 0;
  function flowGate() {
    var gate = document.querySelector('div.absolute.inset-0.z-50');
    if (!gate || !gate.querySelector('img') || !gate.querySelector('button')) return;
    var h = gate.querySelector('h2');
    if (h) {
      var wrap = h.parentElement;
      if (wrap && wrap !== gate && !wrap.querySelector('button,img')) wrap.style.display = 'none';
      else {
        h.style.display = 'none';
        var p = gate.querySelector('p');
        if (p) p.style.display = 'none';
      }
    }
    var now = Date.now();
    if (now - gateAt < 1000) return;
    gateAt = now;
    var btn = gate.querySelector('button');
    var label = btn.querySelector('span') || btn;
    try {
      chrome.tabs.query({}, function (tabs) {
        var open = (tabs || []).some(function (t) {
          try {
            var u = new URL(t.url);
            return u.hostname === 'flow.google.com' || (u.hostname === 'labs.google' && u.pathname.indexOf('flow') >= 0);
          } catch (e) { return false; }
        });
        var txt = open ? 'Volver a Google Flow' : 'Abrir Google Flow';
        if (label.textContent !== txt) label.textContent = txt;
      });
    } catch (e) {}
  }

  function apply() {
    flowGate();
    var panel = document.querySelector('.panel-in');
    if (!panel) return;
    ensureTabs(panel);
    moveLang(panel);
    classify(panel);
    hideDownloads(panel);
    moveClear(panel);
    moveCache(panel);
    moveReport(panel);
    hideBits(panel);
    hideRemoved(panel);
    applyCharBox(panel);
    applyLangConsole(panel);
    stripEmojis(panel);

    logThinBar(panel);
  }

  ensureConsole();
  loadChar();
  apply();
  setInterval(apply, 600);

  // La UI base de React se dibuja antes de que este override la transforme.
  // #root queda oculto por CSS hasta que terminamos el primer pase, asi no se
  // ve el layout viejo ni por un frame.
  var uiRevealed = false;
  function revealUi() {
    if (uiRevealed) return;
    uiRevealed = true;
    try { document.documentElement.classList.add('ez-ready'); } catch (e) {}
  }
  var raf = window.requestAnimationFrame || function (f) { return setTimeout(f, 16); };
  function bootUi() {
    var panel = document.querySelector('.panel-in');
    if (!panel) { raf(bootUi); return; }
    try { apply(); } catch (e) {}
    setTimeout(function () {
      try { apply(); } catch (e) {}
      revealUi();
    }, 60);
  }
  raf(bootUi);

  // Reaccion inmediata: el selector de descargas se crea/borra cuando cambia
  // "Salidas por prompt"; sin esto alcanza a verse hasta el proximo tick.
  try {
    new MutationObserver(function () {
      var panel = document.querySelector('.panel-in');
      if (panel) hideDownloads(panel);
    }).observe(document.body, { childList: true, subtree: true });
  } catch (e) {}
  setInterval(function () { renderConsole(false); }, 800);
  try {
    chrome.storage.onChanged.addListener(function (ch) {
      if (ch.ez_log_content || ch.ez_log_worker) renderConsole(false);
      if (ch.ez_char_src) {
        charSelected = ch.ez_char_src.newValue || null;
        paintChar();
      }
    });
  } catch (e) {}
})();
