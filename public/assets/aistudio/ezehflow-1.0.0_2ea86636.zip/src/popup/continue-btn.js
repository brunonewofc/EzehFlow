// EzehFlow — inject "Continuar Lista" after the queue Run button.
//
// The previous version injected once and matched any button whose text
// contained "run"/"play"/"ejecutar": a Material icon ligature or a tab could
// win, and any React re-render of the side panel dropped the button for good.
// Now:
//   - the real run button is picked by .run-btn / [data-ez-block="run"] first,
//     and only then by a queue label (icon ligatures are rejected);
//   - a MutationObserver + slow interval re-injects the button if React
//     removes it, and keeps it right after the current run button;
//   - visibility is driven by queue_state exactly as before.
(function () {
  'use strict';

  // Un doble click en "Ejecutar cola" manda dos START_QUEUE mientras el estado
  // todavia no llego al popup; el background reinicia la cola y el prompt 1 se
  // despacha dos veces. Este guard corta el segundo click en la ventana corta.
  var lastStartAt = 0;
  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('.run-btn') : null;
    if (!btn) return;
    var label = (btn.textContent || '').toLowerCase();
    if (label.indexOf('cancel') !== -1 || label.indexOf('cancelar') !== -1 || label.indexOf('pause') !== -1) return;
    var now = Date.now();
    if (now - lastStartAt < 1500) {
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    lastStartAt = now;
  }, true);

  var BTN_ID = 'ezehflow-continue-btn';
  var WRAP_ID = 'continue-list-wrapper';
  var QUEUE_KEY = 'queue_state';
  var ICON_ONLY = /^(play_arrow|play_circle|play_circle_fill|smart_display|start|resume|run)$/i;
  var QUEUE_LABEL = /(ejecutar|iniciar|reanudar|run|start|resume)\s+(la\s+)?(cola|queue)/i;

  function isRunButton(btn) {
    if (!btn || btn.tagName !== 'BUTTON' || btn.id === BTN_ID) return false;
    if (btn.closest && btn.closest('#' + WRAP_ID)) return false;
    if (btn.classList && btn.classList.contains('run-btn')) return true;
    if (btn.dataset && btn.dataset.ezBlock === 'run') return true;
    var txt = (btn.textContent || '').replace(/\s+/g, ' ').trim();
    if (!txt || ICON_ONLY.test(txt)) return false;
    return QUEUE_LABEL.test(txt);
  }

  function findRunButton() {
    var run = document.querySelector('button.run-btn');
    if (run && !run.closest('#' + WRAP_ID)) return run;
    var tagged = document.querySelector('button[data-ez-block="run"]');
    if (tagged) return tagged;
    var buttons = document.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i++) {
      if (isRunButton(buttons[i])) return buttons[i];
    }
    return null;
  }

  function applyState(queue) {
    var btn = document.getElementById(BTN_ID);
    if (!btn) return;
    var show = !!queue && !queue.isRunning &&
      typeof queue.currentIndex === 'number' && queue.currentIndex > 0 &&
      Array.isArray(queue.prompts) && queue.currentIndex < queue.prompts.length;
    btn.style.display = show ? 'block' : 'none';
  }

  function refresh() {
    try {
      chrome.storage.local.get(QUEUE_KEY, function (data) {
        applyState(data && data[QUEUE_KEY]);
      });
    } catch (e) { /* extension reloading */ }
  }

  function makeButton() {
    var btn = document.createElement('button');
    btn.id = BTN_ID;
    btn.type = 'button';
    btn.textContent = '▶ Continuar Lista';
    btn.style.display = 'none';
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      btn.style.display = 'none';
      try { chrome.runtime.sendMessage({ type: 'CONTINUE_QUEUE' }); } catch (err) {}
    });
    return btn;
  }

  function ensure() {
    var run = findRunButton();
    if (!run) return;
    var wrap = document.getElementById(WRAP_ID);
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = WRAP_ID;
      wrap.appendChild(makeButton());
      run.insertAdjacentElement('afterend', wrap);
      refresh();
      return;
    }
    // React can replace the run button node: keep the wrapper next to the
    // current one instead of leaving it stranded.
    if (wrap.previousElementSibling !== run) run.insertAdjacentElement('afterend', wrap);
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'local' && changes[QUEUE_KEY]) applyState(changes[QUEUE_KEY].newValue);
    });
  } catch (e) { /* extension reloading */ }

  var pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    setTimeout(function () { pending = false; ensure(); }, 150);
  }

  function start() {
    ensure();
    new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
    setInterval(ensure, 2500);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
