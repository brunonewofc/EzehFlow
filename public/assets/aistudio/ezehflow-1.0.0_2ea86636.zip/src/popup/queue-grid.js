// EzehFlow — compact queue grid.
//
// Replaces the tall "COLA (n)" prompt list with one small square per prompt:
//   grey  = pending
//   amber = generating
//   green = done
//   red   = error
// Hovering a square shows the full prompt text. It reads queue_state from
// storage and, before a run starts, the prompts in the textarea, so the row
// appears as soon as prompts are pasted and colours update while running.
(function () {
  'use strict';

  var QUEUE_KEY = 'queue_state';
  var GRID_ID = 'ez-queue-grid';
  var TIP_ID = 'ez-queue-tip';
  var CSS_ID = 'ez-queue-grid-css';
  var tipEl = null;
  var edited = false;

  var CSS = [
    '#ez-queue-grid{display:grid;grid-template-columns:repeat(20,minmax(0,1fr));gap:3px;margin:2px 0 6px;padding:0 1px;align-items:start}',
    '#ez-queue-grid .ezq-sq{position:relative;display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1;box-sizing:border-box;border-radius:4px;background:#3f3f46;border:1px solid rgba(255,255,255,.10);cursor:help;overflow:hidden;flex:0 0 auto;transition:background .18s,border-color .18s,transform .18s}',
    '#ez-queue-grid .ezq-sq:hover{transform:scale(1.12)}',
    '#ez-queue-grid .ezq-sq:focus{outline:2px solid #f59e0b;outline-offset:1px}',
    '#ez-queue-grid .ezq-sq.running{background:#f59e0b;border-color:rgba(245,158,11,.7)}',
    '#ez-queue-grid .ezq-sq.running::after{content:"";box-sizing:border-box;width:9px;height:9px;border:1.5px solid rgba(0,0,0,.25);border-top-color:#111827;border-radius:50%;animation:ezq-spin .8s linear infinite}',
    '#ez-queue-grid .ezq-sq.done{background:#22c55e;border-color:rgba(34,197,94,.7)}',
    '#ez-queue-grid .ezq-sq.done::after{content:"✓";color:#fff;font:700 11px/1 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}',
    '#ez-queue-grid .ezq-sq.error{background:#ef4444;border-color:rgba(239,68,68,.7)}',
    '#ez-queue-grid .ezq-sq.error::after{content:"✕";color:#fff;font:700 10px/1 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}',
    '@keyframes ezq-spin{to{transform:rotate(360deg)}}',
    // La lista original se oculta por CSS (no solo por style inline) para que
    // no reaparezca ni un frame cuando React la vuelve a renderizar.
    '.panel-in div[class*="max-h-[240px]"]{display:none!important}',
    '#ez-queue-tip{position:fixed;z-index:2147483647;max-width:300px;max-height:55vh;overflow:hidden;padding:7px 9px;border-radius:8px;background:#18181b;border:1px solid rgba(255,255,255,.14);color:#e4e4e7;font:11px/1.4 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;white-space:pre-wrap;overflow-wrap:anywhere;box-shadow:0 8px 24px rgba(0,0,0,.5);pointer-events:none;display:none}'
  ].join('\n');

  function injectCss() {
    if (document.getElementById(CSS_ID)) return;
    var style = document.createElement('style');
    style.id = CSS_ID;
    style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);
  }

  function parsePrompts(text) {
    return String(text || '')
      .split(/\n\s*\n/)
      .map(function (s) { return s.trim(); })
      .filter(function (s) { return s.length > 0; });
  }

  function getTextarea() {
    var panel = document.querySelector('.panel-in');
    return (panel || document).querySelector('textarea');
  }

  // The queue list is the only scrollable max-h-[240px] box in the side panel.
  // Finding it by class avoids depending on the translated "Cola"/"Queue" label.
  function getList() {
    var panel = document.querySelector('.panel-in') || document.body;
    return panel ? panel.querySelector('div[class*="max-h-[240px]"]') : null;
  }

  function statusClass(status) {
    if (status === 'running') return 'running';
    if (status === 'done') return 'done';
    if (status === 'error') return 'error';
    return 'pending';
  }

  function itemsFor(state, textPrompts, forcePending) {
    // Editing/pasting prompts always starts grey again; the stored statuses
    // only take over once the queue is running (or the popup is reopened with
    // an untouched textarea).
    if (forcePending) {
      return textPrompts.map(function (text) { return { text: text, status: 'pending' }; });
    }
    var stored = state && Array.isArray(state.prompts) ? state.prompts : null;
    if (stored && stored.length) {
      var same = stored.length === textPrompts.length;
      if (same) {
        for (var i = 0; i < stored.length; i++) {
          if ((stored[i].text || '') !== textPrompts[i]) { same = false; break; }
        }
      }
      // While running, the state is authoritative. When idle, only reuse the
      // stored statuses if the textarea still holds the same prompts (so an
      // edit shows grey squares again instead of stale colours).
      if (state.isRunning || same) {
        return stored.map(function (p, idx) {
          var status = p.status || 'pending';
          if (status === 'pending' && state.isRunning && idx === state.currentIndex) {
            var waiting = !!state.waitingUntil || /esperando|waiting/i.test(state.waitingReason || '');
            var retrying = (p.retryCount || 0) > 0 || /reintent|retry/i.test(state.waitingReason || '');
            // Mientras la corrida esta activa, el prompt actual se muestra
            // amarillo: al arrancar, y tambien durante un reintento/cooldown.
            if (retrying || !waiting) status = 'running';
          }
          return { text: p.text || '', status: status };
        });
      }
    }
    return textPrompts.map(function (text) { return { text: text, status: 'pending' }; });
  }

  function ensureTip() {
    if (tipEl && tipEl.isConnected) return tipEl;
    tipEl = document.getElementById(TIP_ID);
    if (!tipEl) {
      tipEl = document.createElement('div');
      tipEl.id = TIP_ID;
      document.body.appendChild(tipEl);
    }
    return tipEl;
  }

  function hideTip() {
    if (tipEl) tipEl.style.display = 'none';
  }

  function showTip(square) {
    var text = square && square.getAttribute('data-prompt');
    if (!text) return;
    var tip = ensureTip();
    tip.textContent = text;
    tip.style.display = 'block';
    tip.style.left = '0px';
    tip.style.top = '0px';
    var rect = square.getBoundingClientRect();
    var tr = tip.getBoundingClientRect();
    var left = Math.max(8, Math.min(rect.left, window.innerWidth - tr.width - 8));
    var top = rect.top - tr.height - 8;
    if (top < 8) top = Math.min(window.innerHeight - tr.height - 8, rect.bottom + 8);
    tip.style.left = left + 'px';
    tip.style.top = Math.max(8, top) + 'px';
  }

  function ensureGrid(root) {
    var grid = document.getElementById(GRID_ID);
    if (!grid) {
      grid = document.createElement('div');
      grid.id = GRID_ID;
      grid.setAttribute('data-ezp', '2'); // same tab as the queue section
      grid.setAttribute('data-ez-sec', 'queue');
      grid.setAttribute('role', 'list');
      grid.addEventListener('mouseover', function (e) {
        var sq = e.target && e.target.closest ? e.target.closest('.ezq-sq') : null;
        if (sq) showTip(sq);
      });
      grid.addEventListener('mouseout', function (e) {
        var sq = e.target && e.target.closest ? e.target.closest('.ezq-sq') : null;
        if (sq && !sq.contains(e.relatedTarget)) hideTip();
      });
      grid.addEventListener('focusin', function (e) {
        var sq = e.target && e.target.closest ? e.target.closest('.ezq-sq') : null;
        if (sq) showTip(sq);
      });
      grid.addEventListener('focusout', hideTip);
    }
    var parent = root.parentElement;
    if (!parent) return null;
    // Same order as the "COLA (n)" block (design-override orders blocks by
    // data-ez-block), so the row sits right under the header instead of on top.
    if (grid.getAttribute('data-ez-block') !== 'queue') grid.setAttribute('data-ez-block', 'queue');
    if (grid.parentElement !== parent || root.nextElementSibling !== grid) {
      parent.insertBefore(grid, root.nextSibling);
    }
    return grid;
  }

  function render(grid, items) {
    var signature = items.map(function (it) { return it.status + '\u0001' + it.text; }).join('\u0002');
    if (grid.getAttribute('data-sig') === signature) return;
    grid.setAttribute('data-sig', signature);
    hideTip();
    grid.textContent = '';
    for (var i = 0; i < items.length; i++) {
      var square = document.createElement('div');
      square.className = 'ezq-sq ' + statusClass(items[i].status);
      square.setAttribute('data-prompt', items[i].text);
      square.setAttribute('data-index', String(i + 1));
      square.setAttribute('role', 'listitem');
      square.setAttribute('aria-label', 'Prompt ' + (i + 1) + ': ' + items[i].text);
      square.tabIndex = 0;
      grid.appendChild(square);
    }
  }

  function hideGrid() {
    var grid = document.getElementById(GRID_ID);
    if (grid) grid.style.display = 'none';
    hideTip();
  }

  // Repintado sincronico al pegar/editar: no espera al storage ni al re-render
  // de React, asi no se ve por un instante la fila vieja con errores.
  function paintPending(text) {
    var prompts = parsePrompts(text);
    var list = getList();
    var root = list && list.parentElement;
    if (!root || !prompts.length) { hideGrid(); return; }
    var grid = ensureGrid(root);
    if (!grid) { hideGrid(); return; }
    grid.style.display = '';
    if (list.style.display !== 'none' || list.style.getPropertyPriority('display') !== 'important') {
      list.style.setProperty('display', 'none', 'important');
    }
    render(grid, prompts.map(function (prompt) { return { text: prompt, status: 'pending' }; }));
  }

  function paint(state, textPrompts) {
    var list = getList();
    var root = list && list.parentElement;
    if (!root) { hideGrid(); return; }
    var running = !!(state && state.isRunning);
    if (running) edited = false;
    var items = itemsFor(state, textPrompts, edited && !running);
    if (!items.length) { hideGrid(); return; }
    var grid = ensureGrid(root);
    if (!grid) { hideGrid(); return; }
    grid.style.display = '';
    if (list.style.display !== 'none' || list.style.getPropertyPriority('display') !== 'important') {
      list.style.setProperty('display', 'none', 'important');
    }
    render(grid, items);
  }

  function resetOldSession() {
    try {
      chrome.storage.local.get(QUEUE_KEY, function (data) {
        if (!data || !data[QUEUE_KEY]) return;
        try {
          chrome.runtime.sendMessage({ type: 'RESET_SESSION' }, function () {
            void chrome.runtime.lastError;
          });
        } catch (e) { /* extension reloading */ }
      });
    } catch (e) { /* extension reloading */ }
  }

  function refresh() {
    var textarea = getTextarea();
    var textPrompts = parsePrompts(textarea ? textarea.value : '');
    try {
      chrome.storage.local.get(QUEUE_KEY, function (data) {
        paint(data && data[QUEUE_KEY], textPrompts);
      });
    } catch (e) {
      paint(null, textPrompts);
    }
  }

  var pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    setTimeout(function () { pending = false; refresh(); }, 80);
  }

  function init() {
    injectCss();
    refresh();
    var root = document.querySelector('.panel-in') || document.body;
    new MutationObserver(schedule).observe(root, { childList: true, subtree: true });
    document.addEventListener('input', function (e) {
      if (e.target && e.target.tagName === 'TEXTAREA') {
        edited = true;
        paintPending(e.target.value);
        resetOldSession();
        schedule();
      }
    }, true);
    window.addEventListener('resize', hideTip);
    try {
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area === 'local' && changes[QUEUE_KEY]) schedule();
      });
    } catch (e) { /* extension reloading */ }
    setInterval(refresh, 2500);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
