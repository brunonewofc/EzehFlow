// EzehFlow — arranque limpio del panel.
//
// Cada vez que se abre la extension no debe quedar nada de la sesion anterior:
// ni cola, ni errores, ni logs, ni timers/alarmas/generacion en curso.
// Borra el estado local antes de que React monte el popup y avisa al service
// worker para que corte timers, alarma y generacion en la pestana de Flow.
(function () {
  'use strict';

  var KEYS = [
    'queue_state',
    'autoContinueAfterClear',
    'auto_extend_frame',
    'ez_log_content',
    'ez_log_worker',
  ];

  function reset() {
    try {
      chrome.runtime.sendMessage({ type: 'RESET_SESSION' }, function () {
        void chrome.runtime.lastError;
      });
    } catch (e) { /* extension reloading */ }
  }

  try {
    chrome.storage.local.remove(KEYS, function () {
      void chrome.runtime.lastError;
      reset();
    });
  } catch (e) {
    reset();
  }

  // Red de seguridad: si el override no llega a marcar la UI como lista, no
  // dejar la pantalla en negro para siempre.
  setTimeout(function () {
    try { document.documentElement.classList.add('ez-ready'); } catch (e) {}
  }, 2500);
})();
